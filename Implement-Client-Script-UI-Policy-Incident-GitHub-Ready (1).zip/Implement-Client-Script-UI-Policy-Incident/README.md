# Implement Client Script & UI Policy (Incident)

## Project Overview

This ServiceNow micro project demonstrates how UI Policies and Client Scripts can be used on Incident records to enforce data integrity, automate field behavior, and prevent incorrect data submission.

## Objective

The objective is to demonstrate client-side controls that can:

- Make fields mandatory based on conditions
- Automatically populate field values
- Control field behavior such as read-only
- Validate Incident records before submission
- Prevent direct list editing of the State field

## Technologies / ServiceNow Features

- ServiceNow Incident Management
- UI Policy
- UI Policy Actions
- Client Scripts
- Form Validation

## Project Configuration

### UI Policy

**Name:** High Impact Control  
**Table:** Incident  
**Active:** True  
**Condition:** Impact is 1 - High  
**Reverse if false:** True

### UI Policy Actions

**Assignment group**
- Mandatory: True

**Urgency**
- Read-only: True
- Visible: unchanged

### Client Scripts

1. Auto set urgency for high impact
   - Type: onChange
   - Table: Incident
   - Field: Impact

2. Prevent save if Assigned To missing
   - Type: onSubmit
   - Table: Incident

3. Prevent state change via list edit
   - Type: onCellEdit
   - Table: Incident
   - Field: State

## Expected Behavior

When Impact is set to High:

- Assignment group becomes mandatory.
- Urgency becomes read-only.
- Urgency is automatically set to High.
- Saving is prevented when Assigned To is empty.

When Impact is changed from High to Medium:

- Assignment group is no longer mandatory.
- Urgency becomes editable.

When State is edited directly from the Incident list:

- An alert is displayed.
- The State change is blocked.

State changes made from the Incident form are allowed.

## Testing

The project includes tests for:

- Mandatory enforcement
- Successful save
- Reverse condition
- List edit blocking
- Form-based update

## Screenshots

Add your actual ServiceNow screenshots to the `Screenshots` folder before publishing the repository.

## Conclusion

The project demonstrates how UI Policies and Client Scripts can work together to enforce dynamic field behavior, automate updates, and prevent incorrect Incident submissions.
